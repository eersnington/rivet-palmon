import { describe, expectTypeOf, test } from "vitest";
import type * as BrowserEntry from "./mod.browser.ts";
import type * as ServerEntry from "./mod.ts";

describe("browser entry", () => {
	test("has the exports of the server entry", () => {
		expectTypeOf<keyof typeof BrowserEntry>().toEqualTypeOf<
			keyof typeof ServerEntry
		>();
	});

	test("has the Workflow type of the server entry", () => {
		expectTypeOf<typeof BrowserEntry.Workflow>().toEqualTypeOf<
			typeof ServerEntry.Workflow
		>();
	});
});
